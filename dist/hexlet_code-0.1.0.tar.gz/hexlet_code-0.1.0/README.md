### Hexlet tests and linter status:
[![Actions Status](https://github.com/ttehasi/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ttehasi/python-project-49/actions)

<a href="https://codeclimate.com/github/ttehasi/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/0196f25b462ce6f82ac1/maintainability" /></a>
